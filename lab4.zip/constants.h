

/* COpyright 2023 Neil Kirby */

#define DELTA_T (1.0/64.0)
# define M_PI           3.14159265358979323846  /* pi */

