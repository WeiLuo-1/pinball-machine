/* Wei Luo */

bool init();
int main(int argc, char *argv[]);
void open_run(char *argv[], bool flag) ;
void read_and_run(FILE *fp);
void teardown();
