/* Wei Luo */

bool alwaysTrue(void *data) ;
bool goesInfrontOf(void *data1, void *data2) ;
int main() ;
void print(void *data) ;
