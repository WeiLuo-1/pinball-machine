/* Wei Luo */

bool compare(void *data1, void *data2) ;
int main() ;
void print(void *data) ;
bool under_five(void *data) ;
