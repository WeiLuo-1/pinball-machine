/* Wei Luo */

struct Ball *allocate_ball();
void free_ball(void *data);
