/* Wei Luo */

bool read_all(struct Sim *table, FILE *fp);
